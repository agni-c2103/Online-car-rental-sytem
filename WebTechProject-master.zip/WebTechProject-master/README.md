# WebTechProject
Online Car Rental project created as a sessional project for Information and Web Technology Lab (IT752). 

Stack Specifications:

Backend: Django 2.1  
Frontend: HTML,CSS,JS, Bootstrap   
Database: SQLite3   


To run, open terminal inside the main folder and type
```bash
python manage.py runserver 0.0.0.0:8000
```
